package com.triclope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TriclopeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
